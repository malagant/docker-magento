<?php

/**
 * @package Conlabz_Autoversioning
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Autoversioning_Model_Minify_Js implements Conlabz_Autoversioning_Model_Minify_Interface
{
    const XML_PATH_ADAPTER = 'global/autoversioning/minify/js/adapter';

    /**
     * @var Conlabz_Autoversioning_Model_Minify_Interface
     */
    protected $_adapter;
    
    /**
     * @var array
     */
    protected $_blacklist;

    /**
     * @return Conlabz_Autoversioning_Model_Minify_Interface
     */
    public function getAdapter()
    {
        if (null === $this->_adapter) {
            $configAdapter = (string) Mage::getConfig()->getNode(self::XML_PATH_ADAPTER);
            $this->setAdapter(Mage::getSingleton($configAdapter));
        }
        return $this->_adapter;
    }

    /**
     * @param Conlabz_Autoversioning_Model_Minify_Interface $adapter
     * @return Conlabz_Autoversioning_Model_Minify_Js
     */
    public function setAdapter(Conlabz_Autoversioning_Model_Minify_Interface $adapter)
    {
        $this->_adapter = $adapter;
        return $this;
    }

    /**
     * @param $file
     * @param $content string
     * @return string
     */
    public function minify($file, $content)
    {
        $debug = "\n\n// [DEBUG] file: %s, [compressed: %s]\n";
        $output = ';';
        if (!$this->_canUse($file)) {
            if (Mage::getIsDeveloperMode()) {
                $output.= sprintf($debug, $file, 'false');
            }
            $output.= $content;
            return $output;
        }
        if (Mage::getIsDeveloperMode()) {
            $output.= sprintf($debug, $file, 'true');
        }
        $output.= $this->getAdapter()->minify($file, $content);
        return $output;
    }

    /**
     * @param $file string
     * @return bool
     */
    protected function _canUse($file)
    {
        $path = str_replace(BP, '', $file);
        foreach ($this->_getBlacklist() as $pattern) {
            if (fnmatch($pattern, $path)) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return array
     */
    protected function _getBlacklist()
    {
        if (null === $this->_blacklist) {
            $this->_blacklist = (array) Mage::getConfig()
                ->getNode(self::XML_PATH_MINIFY_BLACKLIST_JS)
                ->asArray();
        }
        return $this->_blacklist;
    }
}
