<?php
use JShrink\Minifier;

/**
 * @package Conlabz_Autoversioning
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Autoversioning_Model_Minify_Adapter_Jshrink implements Conlabz_Autoversioning_Model_Minify_Interface
{
    /**
     * @param $file
     * @param $content string
     * @return string
     */
    public function minify($file, $content)
    {
        return Minifier::minify($content, ['flaggedComments' => false]);
    }
}
