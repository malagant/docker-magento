<?php 
/**
 * Conlabz Autoversioning Helper
 */
class Conlabz_Autoversioning_Helper_Data extends Mage_Core_Helper_Abstract
{
}
