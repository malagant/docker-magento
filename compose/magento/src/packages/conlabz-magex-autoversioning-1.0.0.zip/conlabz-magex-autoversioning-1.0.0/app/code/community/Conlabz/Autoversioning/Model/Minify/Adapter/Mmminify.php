<?php
use MatthiasMullie\Minify;

/**
 * @package Conlabz_Autoversioning
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Autoversioning_Model_Minify_Adapter_Mmminify implements Conlabz_Autoversioning_Model_Minify_Interface
{
    /**
     * @param $file
     * @param $content string
     * @return string
     */
    public function minify($file, $content)
    {
        $minfier = new Minify\JS();
        $minfier->add($content);
        return $minfier->minify();
    }
}
