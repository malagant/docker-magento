<?php

/**
 * @package Conlabz_Autoversioning
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
interface Conlabz_Autoversioning_Model_Minify_Interface
{
    const XML_PATH_MINIFY_BLACKLIST_JS = 'global/autoversioning/minify/js/blacklist';

    /**
     * @param $file
     * @param $content string
     * @return string
     */
    public function minify($file, $content);
}
