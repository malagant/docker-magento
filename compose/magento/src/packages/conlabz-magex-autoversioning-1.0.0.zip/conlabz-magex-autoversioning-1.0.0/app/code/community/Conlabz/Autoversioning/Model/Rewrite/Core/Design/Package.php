<?php

/**
 * @package Conlabz_Autoversioning
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Autoversioning_Model_Rewrite_Core_Design_Package extends Mage_Core_Model_Design_Package
{
    /**
     * Merge specified javascript files and return URL to the merged file on success
     *
     * @param $files
     * @return string
     */
    public function getMergedJsUrl($files)
    {
        $targetFilename = md5(implode(',', $files)) . '.js';
        $targetDir = $this->_initMergerDir('js');
        if (!$targetDir) {
            return '';
        }
        if ($this->_mergeFiles($files, $targetDir . DS . $targetFilename, false, $this->_getJsMinifierCallback(), 'js')) {
            return Mage::getBaseUrl('media', Mage::app()->getRequest()->isSecure()) . 'js/' . $targetFilename;
        }
        return '';
    }

    /**
     * @return Mage_Core_Model_Abstract
     */
    protected function _getJsMinifierCallback()
    {
        return [
            Mage::getSingleton('autoversioning/minify_js'),
            'minify'
        ];
    }
}
