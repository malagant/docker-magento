<?php

/**
 * @package
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Autoversioning_Model_Observer_Head extends Mage_Page_Block_Html_Head
{
    /**
     * @event core_block_abstract_to_html_before
     * @param Varien_Event_Observer $observer
     */
    public function prepareHead(Varien_Event_Observer $observer)
    {
        $event = $observer->getEvent();
        $block = $event->getBlock();
        if (!$block instanceof Mage_Page_Block_Html_Head) {
            return;
        }
        $debug = 1;
    }
}
