<?php

/**
 * @package
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Autoversioning_Model_Minify_Adapter_Dummy implements Conlabz_Autoversioning_Model_Minify_Interface
{
    /**
     * @inheritDoc
     */
    public function minify($file, $content)
    {
        return $content;
    }
}
