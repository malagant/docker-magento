<?php

use JSMin\JSMin;

/**
 * @package Conlabz_Autoversioning
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Autoversioning_Model_Minify_Adapter_Mrclay implements Conlabz_Autoversioning_Model_Minify_Interface
{
    /**
     * @param $file string
     * @param $content string
     * @return string
     */
    public function minify($file, $content)
    {
        return JSMin::minify($content);
    }
}
