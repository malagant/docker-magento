<?php

/**
 *
 * @category    Mage
 * @package     Mage_Admin
 */
class Mage_Admin_Model_Resource_Passwordhashhistory extends Mage_Core_Model_Resource_Db_Abstract
{
    /**
     * Define main table
     *
     */
    protected function _construct()
    {
        $this->_init('admin/user_password_hash_history', 'admin_user_password_hash_history_id');
    }
}
