<?php
/** @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;
$installer->startSetup();

$connection = $installer->getConnection();
$connection->addColumn(
    $installer->getTable('admin/user'), 'force_password_change', array(
        'type'     => Varien_Db_Ddl_Table::TYPE_BOOLEAN,
        'nullable' => false,
        'default'  => 1,
        'comment'  => 'force_password_change'
    )
);

$table = $connection
    ->newTable($installer->getTable('admin/user_password_hash_history'))
    ->addColumn(
        'admin_user_password_hash_history_id',
        Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'identity' => true,
        'unsigned' => true,
        'nullable' => false,
        'primary'  => true,
    ), 'admin_user_password_hash_history_id'
    )
    ->addColumn('admin_user_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'unsigned' => true,
        'nullable' => false,
    ), 'admin_user_id')
    ->addColumn('password_hash', Varien_Db_Ddl_Table::TYPE_TEXT, null, array(),
        'password_hash')
    ->addColumn('created_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
        'default' => Varien_Db_Ddl_Table::TIMESTAMP_INIT
    ), 'created_at')
    ->addIndex(
        $connection->getIndexName(
            $installer->getTable('admin/user_password_hash_history'),
            'admin_user_id'
        ),
        'admin_user_id'
    );
$connection->createTable($table);

$installer->endSetup();
