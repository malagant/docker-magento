<?php

/**
 *
 * @category    Mage
 * @package     Mage_Admin
 */
class Mage_Admin_Model_Resource_Passwordhashhistory_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
    /**
     * Define resource model
     *
     */
    protected function _construct()
    {
        $this->_init('admin/passwordhashhistory');
    }
}
