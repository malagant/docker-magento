<?php
/** @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;
$installer->startSetup();

$installer->getConnection()->addColumn($installer->getTable('admin/user'), 'failed_logins', array(
    'type' => Varien_Db_Ddl_Table::TYPE_INTEGER,
    'length' => 11,
    'nullable' => false,
    'default' => 0,
    'comment' => 'failed login counter'
));

$installer->getConnection()->addColumn($installer->getTable('admin/user'), 'failed_login_hash', array(
    'type' => Varien_Db_Ddl_Table::TYPE_TEXT,
    'length' => 255,
    'nullable' => true,
    'default' => null,
    'comment' => 'failed login reset hash'
));

$installer->endSetup();
