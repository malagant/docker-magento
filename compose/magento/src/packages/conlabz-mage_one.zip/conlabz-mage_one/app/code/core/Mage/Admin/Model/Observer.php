<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magento.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magento.com for more information.
 *
 * @category    Mage
 * @package     Mage_Admin
 * @copyright  Copyright (c) 2006-2020 Magento, Inc. (http://www.magento.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Admin observer model
 *
 * @category    Mage
 * @package     Mage_Admin
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_Admin_Model_Observer
{
    const FLAG_NO_LOGIN = 'no-login';

    private $alreadyCalled = false;
    /**
     * Handler for controller_action_predispatch event
     *
     * @param Varien_Event_Observer $observer
     * @return boolean
     */
    public function actionPreDispatchAdmin($observer)
    {
        /** @var $session Mage_Admin_Model_Session */
        $session = Mage::getSingleton('admin/session');

        /** @var $request Mage_Core_Controller_Request_Http */
        $request = Mage::app()->getRequest();

        /** @var $user Mage_Admin_Model_User */
        $user = $session->getUser();

        $requestedActionName = strtolower($request->getActionName());
        $openActions = array(
            'forgotpassword',
            'resetpassword',
            'resetpasswordpost',
            'logout',
            'refresh', // captcha refresh,
            'failedloginsendreset',
            'failedloginreset',
        );
        if (in_array($requestedActionName, $openActions)) {
            $request->setDispatched(true);
        } else {
            if ($user) {
                $user->reload();

                if ($this->userMustChangePassword($user)
                    && ($request->getControllerName() != 'system_account'
                    || !in_array($requestedActionName, ['index', 'save']))
                ) {
                    if($this->isAllowedToChangePassword()) {
                        $this->changePasswordNoticeAndRedirect();
                    } else {
                        $this->logoutAndInformAdminError();
                    }

                }
            }
            if (!$user || !$user->getId()) {
                if ($request->getPost('login')) {

                    /** @var Mage_Core_Model_Session $coreSession */
                    $coreSession = Mage::getSingleton('core/session');

                    if ($coreSession->validateFormKey($request->getPost("form_key"))) {
                        $postLogin = $request->getPost('login');
                        $username = isset($postLogin['username']) ? $postLogin['username'] : '';
                        $password = isset($postLogin['password']) ? $postLogin['password'] : '';
                        $session->login($username, $password, $request);
                        $request->setPost('login', null);
                    } else {
                        if ($request && !$request->getParam('messageSent')) {
                            Mage::getSingleton('adminhtml/session')->addError(
                                Mage::helper('adminhtml')->__('Invalid Form Key. Please refresh the page.')
                            );
                            $request->setParam('messageSent', true);
                        }
                    }

                    $coreSession->renewFormKey();
                }
                if (!$request->getInternallyForwarded()) {
                    $request->setInternallyForwarded();
                    if ($request->getParam('isIframe')) {
                        $request->setParam('forwarded', true)
                            ->setControllerName('index')
                            ->setActionName('deniedIframe')
                            ->setDispatched(false);
                    } elseif ($request->getParam('isAjax')) {
                        $request->setParam('forwarded', true)
                            ->setControllerName('index')
                            ->setActionName('deniedJson')
                            ->setDispatched(false);
                    } else {
                        $request->setParam('forwarded', true)
                            ->setRouteName('adminhtml')
                            ->setControllerName('index')
                            ->setActionName('login')
                            ->setDispatched(false);
                    }
                    return false;
                }
            }
        }

        $session->refreshAcl();
    }

    /**
     * Unset session first visit flag after displaying page
     *
     * @deprecated after 1.4.0.1, logic moved to admin session
     * @param Varien_Event_Observer $event
     */
    public function actionPostDispatchAdmin($event)
    {
    }

    /**
     * Validate admin password and upgrade hash version
     *
     * @param Varien_Event_Observer $observer
     */
    public function actionAdminAuthenticate($observer)
    {
        $password = $observer->getEvent()->getPassword();
        $user = $observer->getEvent()->getUser();
        $authResult = $observer->getEvent()->getResult();

        if (!$authResult) {
            return;
        }

        if (
            !(bool)$user->getPasswordUpgraded()
            && !Mage::helper('core')->getEncryptor()->validateHashByVersion(
                $password,
                $user->getPassword(),
                Mage_Core_Model_Encryption::HASH_VERSION_SHA256
            )
        ) {
            Mage::getModel('admin/user')->load($user->getId())
                ->setNewPassword($password)->setForceNewPassword(true)
                ->save();
            $user->setPasswordUpgraded(true);
        }
    }

    /**
     * @param Varien_Event_Observer $observer
     */
    public function adminUserAuthenticateBefore($observer)
    {
        if (!Mage::getStoreConfigFlag(Mage_Admin_Model_User::XML_PATH_ADMIN_SECURITY_ENABLE_BRUTE_FORCE_PROTECTION)) {
            return;
        }

        $user = $observer->getEvent()->getUsername();
        $user = Mage::getModel('admin/user')->loadByUsername($user);

        if ($user->getId() && $user->isMaxLoginFailsReached()) {
            Mage::getSingleton('adminhtml/session')->addError(
                Mage::helper('adminhtml')->__('To send an email with a link to reset your login counter, please click <a href="%s">here</a>',
                    Mage::getUrl('adminhtml/index/failedLoginSendReset', array('id' => $user->getId())))
            );

            Mage::app()->getResponse()->setRedirect(Mage::getUrl('adminhtml/index'))->sendHeadersAndExit();
        }
    }

    /**
     * @param Varien_Event_Observer $observer
     */
    public function adminSessionUserLoginSuccess($observer)
    {
        if (!Mage::getStoreConfigFlag(Mage_Admin_Model_User::XML_PATH_ADMIN_SECURITY_ENABLE_BRUTE_FORCE_PROTECTION)) {
            return;
        }

        /** @var Mage_Admin_Model_User $user */
        $user = $observer->getEvent()->getUser();
        $user->load($user->getId());

        if ($user->getId()) {
            $user->resetFailedLogins();
            $user->save();
        }
    }

    /**
     * @param Varien_Event_Observer $observer
     */
    public function adminSessionUserLoginFailed($observer)
    {
        if (!Mage::getStoreConfigFlag(Mage_Admin_Model_User::XML_PATH_ADMIN_SECURITY_ENABLE_BRUTE_FORCE_PROTECTION)) {
            return;
        }

        /** @var Mage_Admin_Model_User $user */
        $userName = $observer->getEvent()->getUserName();
        $user = Mage::getModel('admin/user')->loadByUsername($userName);

        if ($user->getId()) {
            $user->countUpFailedLogin();
            $user->save();
        }
    }

    /**
     * @param Varien_Event_Observer $observer
     */
    public function adminUserSaveAfter($observer)
    {
        if (!Mage::getStoreConfigFlag(Mage_Admin_Model_User::XML_PATH_ADMIN_SECURITY_ENABLE_BRUTE_FORCE_PROTECTION)) {
            return;
        }

        /** @var Mage_Admin_Model_User $user */
        $user = $observer->getEvent()->getObject();

        if ($user->getData('password') !== $user->getOrigData('password')) {
            Mage::dispatchEvent('admin_user_changed_password', array(
                'user' => $user
            ));
        }
    }

    /**
     * @param Varien_Event_Observer $observer
     */
    public function adminUserChangedPassword($observer)
    {
        if (!Mage::getStoreConfigFlag(Mage_Admin_Model_User::XML_PATH_ADMIN_SECURITY_ENABLE_BRUTE_FORCE_PROTECTION)) {
            return;
        }

        /** @var Mage_Admin_Model_User $user */
        $user = $observer->getEvent()->getUser();
        $user->load($user->getId());

        if ($user->getId()) {
            $user->resetFailedLogins();
            $user->save();
        }
    }

    /**
     * @param Varien_Event_Observer $observer
     */
    public function adminUserChangedPasswordStrength(Varien_Event_Observer $observer)
    {
        /** @var Mage_Adminhtml_Model_Config_Data $config */
        $config = $observer->getObject();

        if ($config->getSection() == 'admin') {
            $oldValue = (string)$config->getConfigDataValue(Mage_Admin_Model_User::XML_PATH_ADMIN_SECURITY_ADMIN_PASSWORD_STRENGTH);
            $newValue = (string)$config->getData('groups/security/fields/admin_password_strength/value');

            if ($oldValue === $newValue) {
                return;
            }

            if ($oldValue === Mage_Core_Model_Passwordstrength::MAGENTO_DEFAULT
                && in_array($newValue, [
                    Mage_Core_Model_Passwordstrength::PCI,
                    Mage_Core_Model_Passwordstrength::PCI_ADVANCED
                ], true)
            ) {
                $adminUserCollection = Mage::getModel('admin/user')
                    ->getCollection();

                foreach ($adminUserCollection as $adminUser) {
                    $adminUser->setForcePasswordChange(true)->save();
                }
            }
        }
    }

    /**
     * @param Mage_Admin_Model_User $user
     *
     * @return bool
     */
    private function userMustChangePassword(Mage_Admin_Model_User $user)
    {
        return $this->passwordSafetyIsPci()
            && ($user->getForcePasswordChange()
                || $user->isLastPasswordOlderThan90Days());
    }

    /**
     * @return bool
     */
    private function passwordSafetyIsPci()
    {
        return in_array(
            Mage::getStoreConfig(
                Mage_Admin_Model_User::XML_PATH_ADMIN_SECURITY_ADMIN_PASSWORD_STRENGTH
            ), [Mage_Core_Model_Passwordstrength::PCI,
                Mage_Core_Model_Passwordstrength::PCI_ADVANCED],
            true
        );
    }

    /**
     * @return void
     */
    private function changePasswordNoticeAndRedirect()
    {
        Mage::getSingleton('adminhtml/session')->addError(
            Mage::helper('adminhtml')->__(
                'Please change your password, due to PCI restrictions'
            )
        );

        Mage::app()->getResponse()->setRedirect(
            Mage::getModel('adminhtml/url')
                ->getUrl('adminhtml/system_account/index')
        )->sendHeadersAndExit();
    }

    private function logoutAndInformAdminError()
    {
        if ($this->alreadyCalled) {
            return;
        }
        $this->alreadyCalled = true;
        /** @var Mage_Admin_Model_Session $adminSession */
        $adminSession = Mage::getSingleton('admin/session');
        $adminSession->unsetAll();
        Mage::getSingleton('adminhtml/session')->addError(
            Mage::helper('adminhtml')->__(
                'Due to PCI restrictions you need to change your password, but you are missing the right to do so. Please contact your admin to grant you permission to access "System > My account".'
            )
        );

        throw (new Mage_Core_Controller_Varien_Exception())
            ->prepareForward('index');
    }

    private function isAllowedToChangePassword()
    {
        return Mage::getSingleton('admin/session')
            ->isAllowed('admin/system/myaccount');
    }
}
