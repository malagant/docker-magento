<?php

/**
 * @method int getAdminUserId()
 * @method Mage_Admin_Model_Passwordhashhistory setAdminUserId(int $value)
 * @method string getPasswordHash()
 * @method Mage_Admin_Model_Passwordhashhistory setPasswordHash(string $value)
 * @method string getCreatedAt()
 * @method Mage_Admin_Model_Passwordhashhistory setCreatedAt(string $value)
 *
 * @category    Mage
 * @package     Mage_Admin
 */
class Mage_Admin_Model_Passwordhashhistory extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('admin/passwordhashhistory');
    }

    public function getId()
    {
        return $this->getAdminUserPasswordHashHistoryId();
    }
}
