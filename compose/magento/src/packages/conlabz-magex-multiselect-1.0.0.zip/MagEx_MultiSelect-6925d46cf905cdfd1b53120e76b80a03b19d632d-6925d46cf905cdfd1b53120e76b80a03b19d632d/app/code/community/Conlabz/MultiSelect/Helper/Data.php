<?php

/**
 * @package Conlabz_MultiSelect
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_MultiSelect_Helper_Data
    extends Mage_Core_Helper_Abstract
{
    
}
