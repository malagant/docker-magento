<?php

/**
 * @package Conlabz_MultiSelect
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_MultiSelect_Block_Javascript
    extends Mage_Core_Block_Template
{
    protected $_template = 'conlabz/multiselect/javascript.phtml';
        
    /**
     * 
     * @return string|boolean
     */
    public function getLocaleJs()
    {
        $localeCode = Mage::app()->getLocale()->getLocaleCode();
        $jsLocaleCode = substr($localeCode, 0, 2);
        
        $jsLocaleUrl = 'conlabz/multiselect/locale/' . $jsLocaleCode . '.js';        
        $jsLocaleFile = Mage::getBaseDir()
            . '/js/' . $jsLocaleUrl;
        
        if (is_file($jsLocaleFile)) {
            return Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS) . $jsLocaleUrl;
        }
        
        return false;
    }
    
    /**
     * 
     * @return string
     */
    public function getExcludeSelector()
    {
        $selectors = explode("\n", Mage::getStoreConfig('admin/multiselect/exclude_selectors'));
        return implode(', ', $selectors);
    }
    
    /**
     * 
     * @return int
     */
    public function getInterval()
    {
        return (int) Mage::getStoreConfig('admin/multiselect/refresh_interval');
    }
    
    /**
     * 
     * @return string
     */
    public function getOptionsJs()
    {
        return Mage::helper('core')->jsonEncode($this->getOptions());
    }
    
    /**
     * 
     * @return array
     */
    public function getOptions()
    {
        return array(
            'show' => 'fade',
            'hide' => 'fade',
            'selectedList' => 3
        );
    }
}
