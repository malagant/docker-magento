(function($) {
    $.extend($.ech.multiselect.prototype.options, {
        checkAllText: 'Alle auswählen',
        uncheckAllText: 'Alle abwählen',
        noneSelectedText: 'Nichts ausgewählt',
        selectedText: '# von # ausgewählt'
    });

    $.extend($.ech.multiselectfilter.prototype.options, {
        label: "Suchen:",
        placeholder: "Stichwort eingeben"
    });
})(jQuery);
