<?php

/**
 * @package Conlabz_Schema
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
interface Conlabz_Schema_Block_Jsonld_Interface
{
    /**
     * @return array
     */
    public function getSchema();
}
