<?php

/**
 * @package Conlabz_Schema
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Schema_Block_Jsonld_Product extends Mage_Catalog_Block_Product_View_Abstract
    implements Conlabz_Schema_Block_Jsonld_Interface
{
    /**
     * @var string
     */
    protected $_template = 'schema/jsonld.phtml';

    /**
     * @return Conlabz_Schema_Helper_Data
     */
    protected function _getHelper()
    {
        return Mage::helper('schema');
    }

    /**
     * @return string
     */
    protected function _toHtml()
    {
        $html = '';
        if ($this->_getHelper()->isActive()) {
            $html = parent::_toHtml();
        }
        return $html;
    }

    /**
     * @return array
     */
    public function getSchema()
    {
        /** @var Mage_Catalog_Model_Product $product */
        $product    = $this->getProduct();
        /** @var Mage_Tax_Helper_Data $tax */
        $tax        = $this->helper('tax');
        /** @var Mage_Core_Model_Store $store */
        $store      = Mage::app()->getStore();
        /** @var Mage_Catalog_Helper_Output $output */
        $output     = $this->helper('catalog/output');
        /** @var Mage_CatalogInventory_Model_Stock_Item $stock */
        $stock      = $product->getStockItem();

        $schema = array(
            '@context'      => 'http://schema.org',
            '@type'         => 'Product',
            'name'          => $this->stripTags($output->productAttribute($product, $product->getName(), 'name')),
            'description'   => $this->stripTags($output->productAttribute($product, $product->getDescription(), 'description')),
            'url'           => $product->getProductUrl(),
            'image'         => (string) $this->helper('catalog/image')->init($product, 'image'),
            'offers'        => array(
                '@type'         => 'Offer',
                'price'         => $tax->getPrice($product, $store->roundPrice(
                    $store->convertPrice($product->getFinalPrice())
                )),
                'priceCurrency' => $store->getCurrentCurrency()->getCode(),
                'availability'  => 'http://schema.org/' . ($stock->getIsInStock() ? 'InStock' : 'OutOfStock')
            )
        );
        $schema = new Varien_Object($schema);
        Mage::dispatchEvent(
            'schema_block_jsonld_product',
            array(
                'schema'  => $schema,
                'product' => $product
            )
        );
        $schema = $schema->getData();
        return $schema;
    }
}
