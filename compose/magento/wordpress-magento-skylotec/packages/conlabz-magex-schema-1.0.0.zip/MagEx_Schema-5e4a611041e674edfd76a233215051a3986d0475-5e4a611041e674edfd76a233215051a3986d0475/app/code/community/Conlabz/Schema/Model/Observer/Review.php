<?php

/**
 * @package Conlabz_Schema
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_Schema_Model_Observer_Review
{
    /**
     * adds review/rating data to schema
     *
     * @event schema_block_jsonld_product
     * @param Varien_Event_Observer $observer
     */
    public function addReviewSchema(Varien_Event_Observer $observer)
    {
        $event = $observer->getEvent();
        /* @var $schema Varien_Object */
        $schema = $event->getSchema();
        /* @var $product Mage_Catalog_Model_Product */
        $product = $event->getProduct();

        $storeId = Mage::app()->getStore()->getId();

        $summaryData = Mage::getModel('review/review_summary')
            ->setStoreId($storeId)
            ->load($product->getId())
            ->getData();

        if (!empty($summaryData['rating_summary'])) {
            $summary = array(
                '@type' => 'AggregateRating',
                'ratingValue' => $summaryData['rating_summary'] / 100 * 5,
                'reviewCount' => $summaryData['reviews_count']
            );
            $schema->setData('aggregateRating', $summary);
        }        
    }
}
