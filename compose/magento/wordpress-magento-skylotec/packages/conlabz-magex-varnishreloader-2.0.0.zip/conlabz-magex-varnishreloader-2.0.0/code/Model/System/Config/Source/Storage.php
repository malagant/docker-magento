<?php

/**
 * @package Conlabz_VarnishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_VarnishReloader_Model_System_Config_Source_Storage
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => 'sessionStorage',
                'label' => 'sessionStorage'
            ],
            [
                'value' => 'localStorage',
                'label' => 'localStorage'
            ]
        ];
    }
}
