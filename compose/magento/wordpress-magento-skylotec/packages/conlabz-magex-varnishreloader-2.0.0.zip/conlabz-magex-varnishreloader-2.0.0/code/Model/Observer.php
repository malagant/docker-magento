<?php
/**
 * Observer Model
 *
 * @package Conlabz_VarishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_VarnishReloader_Model_Observer
{
    const XML_PATH_ESI_STRATEGIES = 'global/varnishreloader/esi_strategies';

    /**
     * @var Conlabz_VarnishReloader_Model_Esi_Strategy_Interface[]
     */
    protected $_esiStrategies = [];

    /**
     * Conlabz_VarnishReloader_Model_Observer constructor.
     */
    public function __construct()
    {
        $this->_addEsiStrategiesFromConfig();
    }

    protected function _addEsiStrategiesFromConfig()
    {
        $config = Mage::getConfig()->getNode(self::XML_PATH_ESI_STRATEGIES);
        if (!$config) {
            return;
        }
        foreach ($config->asArray() as $name => $item) {
            if (!isset($item['class'])) {
                continue;
            }
            $strategy = Mage::getSingleton($item['class']);
            if ($strategy) {
                $this->addEsiStrategy($name, $strategy);
            }
        }
    }

    /**
     * @param string $method
     * @param Conlabz_VarnishReloader_Model_Esi_Strategy_Interface $strategy
     */
    public function addEsiStrategy(
        $method,
        Conlabz_VarnishReloader_Model_Esi_Strategy_Interface $strategy
    ) {
        $this->_esiStrategies[$method] = $strategy;
    }

    /**
     * @param string $method
     * @return bool
     */
    public function removeEsiStrategy($method)
    {
        if (isset($this->_esiStrategies[$method])) {
            unset($this->_esiStrategies[$method]);
            return true;
        }
        return false;
    }

    /**
     * @param string $method
     * @return bool|Conlabz_VarnishReloader_Model_Esi_Strategy_Interface
     */
    public function getEsiStrategy($method)
    {
        return isset($this->_esiStrategies[$method])
            ? $this->_esiStrategies[$method]
            : false;
    }

    /**
     * @event controller_action_predispatch
     *
     * @param Varien_Event_Observer $observer
     * @return $this
     */
    public function processPreDispatch(Varien_Event_Observer $observer)
    {
        $controllerAction = $observer->getEvent()->getControllerAction();
        /* @var $request Mage_Core_Controller_Request_Http */
        $request = $controllerAction->getRequest();
        $fullActionName = $controllerAction->getFullActionName();
        $this->_processRefreshCookie($request, $fullActionName);

        if ($this->_getHelper()->storageHasMessages()) {
            Phoenix_VarnishCache_Helper_Cache::setNoCacheHeader();
            Mage::register(Phoenix_VarnishCache_Helper_Cache::REGISTRY_VAR_VARNISH_CACHE_CONTROL_HEADERS_SET_FLAG, 1, true);
        }

        return $this;
    }

    /**
     *
     * @param Mage_Core_Controller_Request_Http $request
     * @param string $fullActionName
     */
    protected function _processRefreshCookie(Mage_Core_Controller_Request_Http $request, $fullActionName)
    {
        $refreshActions = $this->_getHelper()->getRefreshActions();
        if ($request->isPost() ||
            in_array($fullActionName, $refreshActions)
        ) {
            $this->_getHelper()->setRefreshCookie();
        }
    }

    /**
     * @event controller_action_predispatch
     * @param Varien_Event_Observer $observer
     */
    public function cookieCsrf(Varien_Event_Observer $observer)
    {
        $controller = $observer->getControllerAction();
        $request    = $controller->getRequest();
        $formKey    = $request->getParam('form_key', null);

        if (null === $formKey) {
            return;
        }

        $session        = Mage::getSingleton('core/session');
        $sessionFormKey = $session->getFormKey();
        $cookieFormKey  = Mage::getSingleton('core/cookie')->get(Phoenix_VarnishCache_Helper_Esi::FORMKEY_COOKIE);

        if ($formKey !== $sessionFormKey
            && false === $cookieFormKey
            && !$session->hasFirstCall()
        ) {
            $request->setParam('form_key', $sessionFormKey);
        } else if ($cookieFormKey && $cookieFormKey === $sessionFormKey) {
            $request->setParam('form_key', $cookieFormKey);
        }
        $session->setFirstCall(true);
    }

    /**
     * @event core_block_abstract_to_html_before
     * @param Varien_Event_Observer $observer
     */
    public function injectEsi(Varien_Event_Observer $observer)
    {
        if ($this->_getHelper()->isUncacheableAction()) {
            return;
        }

        /** @var Mage_Core_Block_Abstract $block */
        $block   = $observer->getBlock();
        $options = $block->getEsiOptions();

        if (!is_array($options) || $block->getIsEsiRequest()) {
            return;
        }

        $method = isset($options['method']) ? $options['method'] : 'ajax';
        $esiStrategy = $this->getEsiStrategy($method);
        if ($esiStrategy) {
            $esiStrategy->inject($block, $options);
        }
    }

    /**
     * @return Conlabz_VarnishReloader_Helper_Data
     */
    protected function _getHelper()
    {
        return Mage::helper('varnishreloader');
    }
}
