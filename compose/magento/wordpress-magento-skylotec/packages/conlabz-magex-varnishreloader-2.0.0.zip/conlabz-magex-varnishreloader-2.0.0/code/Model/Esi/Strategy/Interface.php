<?php

/**
 * @package Conlabz_VarnishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
interface Conlabz_VarnishReloader_Model_Esi_Strategy_Interface
{
    /**
     * @param Mage_Core_Block_Abstract $block
     * @param array $options
     * @return mixed
     */
    public function inject(Mage_Core_Block_Abstract $block, array $options = []);
}
