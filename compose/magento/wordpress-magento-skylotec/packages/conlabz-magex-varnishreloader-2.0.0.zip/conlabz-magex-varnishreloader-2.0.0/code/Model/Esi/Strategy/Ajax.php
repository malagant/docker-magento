<?php

/**
 * @package Conlabz_VarnishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_VarnishReloader_Model_Esi_Strategy_Ajax implements Conlabz_VarnishReloader_Model_Esi_Strategy_Interface
{
    /**
     * @param Mage_Core_Block_Abstract $block
     * @param array $options
     * @return mixed
     */
    public function inject(Mage_Core_Block_Abstract $block, array $options = [])
    {
        $layout = Mage::app()->getLayout();

        $placeholderTemplate = isset($options['template']) ? $options['template'] : null;
        $placeholderType     = isset($options['type'])     ? $options['type']     : null;

        if ($block instanceof Mage_Core_Block_Template) {
            $block->setTemplate('varnishreloader/placeholder/ajax.phtml');
        } else {
            $block->setFrameTags(sprintf(
                'div %s="%s"',
                Conlabz_VarnishReloader_Block_Javascript::DATA_KEY,
                $block->getNameInLayout()
            ), '/div');
        }
        $block->unsetChildren();
        if (null !== $placeholderType) {
            $placeholderContent = $layout->createBlock(
                $placeholderType,
                $block->getNameInLayout() . '_placeholder',
                array(
                    'template' => $placeholderTemplate,
                )
            );
            $block->append($placeholderContent, 'placeholder');
        }
    }
}
