<?php

/**
 * @package Conlabz_VarnishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_VarnishReloader_Model_Esi_Strategy_Esi implements Conlabz_VarnishReloader_Model_Esi_Strategy_Interface
{
    /**
     * @param Mage_Core_Block_Abstract $block
     * @param array $options
     * @return mixed
     */
    public function inject(Mage_Core_Block_Abstract $block, array $options = [])
    {
        if (!$this->_hasSurrogateCapability()) {
            return;
        }
        $block->setTemplate('varnishreloader/placeholder/esi.phtml');
        $block->setEsiRemove('ESI Placeholder');
        $block->setEsiUrl($this->getEsiUrl($block));
        $this->_setSurrogateControlHeader();
    }

    /**
     * @return bool
     */
    protected function _hasSurrogateCapability()
    {
        $request = Mage::app()->getRequest();
        $headerValue = $request->getHeader('Surrogate-Capability');
        if ($headerValue && false !== strpos($headerValue, 'ESI/1.0')) {
            return true;
        }
        return false;
    }

    /**
     * set header for varnish esi processing
     */
    protected function _setSurrogateControlHeader()
    {
        $response = Mage::app()->getResponse();
        $response->setHeader('Surrogate-Control', 'ESI/1.0', true);
    }

    /**
     *
     * @param Mage_Core_Block_Template $block
     * @return string
     */
    public function getEsiUrl(Mage_Core_Block_Template $block)
    {
        $esiUrl = Mage::getUrl('varnishreloader/refresh/esi', array(
            'block' => $block->getNameInLayout()
        ));
        // must be unsecure
        $esiUrl = str_replace('https:', 'http:', $esiUrl);
        return $esiUrl;
    }
}
