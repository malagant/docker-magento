<?php

/**
 *  
 * @package Conlabz_VarnishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_VarnishReloader_Helper_Data extends Mage_Core_Helper_Abstract
{
    /**
     * system.xml
     */
    const XML_PATH_REFRESH_ACTIONS  = 'varnishcache/varnishreloader/refresh_actions';
    const XML_PATH_DEBUG            = 'varnishcache/varnishreloader/debug';
    const XML_PATH_MESSAGE_SELECTOR = 'varnishcache/varnishreloader/msg_selector';
    const XML_PATH_STORAGE          = 'varnishcache/varnishreloader/storage';

    /**
     * config.xml
     */
    const XML_PATH_SESSION_STORAGES = 'global/varnishreloader/session_storages';

    const COOKIE_FORCE_REFRESH = 'vrForceRefresh';

    /**
     * @var array
     */
    protected $_sessionStorages;

    /**
     * current full action name: module_controller_action
     * 
     * @var string
     */
    protected $_fullActionName;
    
    /**
     *
     * @var array
     */
    protected $_nonCacheableActionsCache = array();

    /**
     * 
     * @return boolean
     */
    public function isDebug()
    {
        return Mage::getStoreConfigFlag(self::XML_PATH_DEBUG);
    }

    /**
     * @param int $store
     * @return mixed
     */
    public function getMessageSelector($store = null)
    {
        return Mage::getStoreConfig(self::XML_PATH_MESSAGE_SELECTOR, $store);
    }

    /**
     * @param int $store
     * @return mixed
     */
    public function getStorage($store = null)
    {
        return Mage::getStoreConfig(self::XML_PATH_STORAGE, $store);
    }

    /**
     * @return array
     */
    public function getRefreshActions()
    {
        $refreshActions = explode("\n", Mage::getStoreConfig(self::XML_PATH_REFRESH_ACTIONS));
        foreach ($refreshActions as &$refreshAction) {
            $refreshAction = trim($refreshAction);
        }
        return array_filter($refreshActions);
    }

    /**
     * @param mixed $value
     */
    public function setRefreshCookie($value = 1)
    {
        Mage::getSingleton('core/cookie')
            ->set(self::COOKIE_FORCE_REFRESH, $value, null, null, null, false, false);
    }

    /**
     * deletes refresh cookie
     */
    public function deleteRefreshCookie()
    {
        Mage::getSingleton('core/cookie')
            ->delete(self::COOKIE_FORCE_REFRESH);
    }

    /**
     * 
     * @return string
     */
    public function getFullActionName()
    {
        if (null === $this->_fullActionName) {
            $request = Mage::app()->getRequest();
            $this->_fullActionName = $request->getRequestedRouteName().'_'.
                $request->getRequestedControllerName().'_'.
                $request->getRequestedActionName();
        }        
        return $this->_fullActionName;
    }
    
    /**
     * 
     * @param string $fullActionName
     * @return boolean
     */
    public function isUncacheableAction($fullActionName = null)
    {
        if (null === $fullActionName) {
            $fullActionName = $this->getFullActionName();
        }        
        if (!isset($this->_nonCacheableActionsCache[$fullActionName])) {
            $this->_nonCacheableActionsCache[$fullActionName] = false;
            $disableRoutes = explode("\n", trim(Mage::getStoreConfig(Phoenix_VarnishCache_Helper_Cache::XML_PATH_VARNISH_CACHE_DISABLE_ROUTES)));
            foreach ($disableRoutes as $route) {
                $route = trim($route);
                // if route is found at first position we have a hit
                if (!empty($route) && strpos($fullActionName, $route) === 0) {
                    $this->_nonCacheableActionsCache[$fullActionName] = true;
                    break;
                }
            }            
        }
        return $this->_nonCacheableActionsCache[$fullActionName];
    }

    /**
     * @return bool
     */
    public function storageHasMessages()
    {
        foreach ($this->getSessionStorages() as $sessionStorage) {
            /** @var Mage_Core_Model_Session_Abstract $storage */
            $storage = Mage::getSingleton($sessionStorage);
            if ($storage) {
                $messageCount = $storage->getMessages(false)->count();
                if ($messageCount > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @return array
     */
    public function getSessionStorages()
    {
        if (null === $this->_sessionStorages) {
            $this->_sessionStorages = [];
            $config = Mage::getConfig()->getNode(self::XML_PATH_SESSION_STORAGES);
            if ($config) {
                $sessionStorages = $config->asArray();
                foreach ($sessionStorages as $sessionStorage) {
                    if ($sessionStorage) {
                        $this->_sessionStorages[] = $sessionStorage;
                    }
                }
            }
        }
        return $this->_sessionStorages;
    }
}
