<?php

/**
 * @package Conlabz_VarnishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_VarnishReloader_Helper_Cache extends Phoenix_VarnishCache_Helper_Cache
{
    const XML_PATH_VARNISH_CACHE_ENABLE_CACHING_HTTPS = 'varnishcache/general/enable_caching_https';

    /**
     * overridden: do not set no cache cookie
     *
     * @param bool
     * @return Phoenix_VarnishCache_Helper_Cache
     */
    public function setNoCacheCookie($renewOnly = false)
    {
        return $this;
    }

    /**
     * Set appropriate cache control headers
     *
     * @return Phoenix_VarnishCache_Helper_Cache
     */
    public function setCacheControlHeaders()
    {
        if (Mage::registry(self::REGISTRY_VAR_VARNISH_CACHE_CONTROL_HEADERS_SET_FLAG)) {
            return $this;
        } else {
            Mage::register(self::REGISTRY_VAR_VARNISH_CACHE_CONTROL_HEADERS_SET_FLAG, 1);
        }

        // set debug header
        if (Mage::helper('varnishcache')->isDebug()) {
            $this->setDebugHeader();
        }

        if (Mage::app()->getStore()->isCurrentlySecure() &&
            !Mage::getStoreConfigFlag(self::XML_PATH_VARNISH_CACHE_ENABLE_CACHING_HTTPS)
        ) {
            return $this->setNoCacheHeader();
        }

        $request = Mage::app()->getRequest();

        // check for disable caching vars
        if ($disableCachingVars = trim(Mage::getStoreConfig(self::XML_PATH_VARNISH_CACHE_DISABLE_CACHING_VARS))) {
            foreach (explode(',', $disableCachingVars) as $param) {
                if ($request->getParam(trim($param))) {
                    $this->setNoCacheHeader();
                }
            }
        }

        // disable page caching for POSTs
        if ($request->isPost()) {
            return $this->setNoCacheHeader();
        }

        // disable page caching for due to HTTP status codes
        if (!in_array(Mage::app()->getResponse()->getHttpResponseCode(), array(200, 301, 404))) {
            return $this->setNoCacheHeader();
        }

        // disable page caching for certain GET parameters
        $noCacheGetParams = explode(',', Mage::getStoreConfig('varnishcache/general/disable_caching_vars'));
        foreach($noCacheGetParams as $param) {
            if($request->getParam($param) !== null) {
                return $this->setNoCacheHeader();
            }
        }

        // disable page caching because of configuration
        if (Mage::getStoreConfigFlag(self::XML_PATH_VARNISH_CACHE_DISABLE_CACHING)) {
            return $this->setNoCacheHeader();
        }

        /**
         * Check for ruleset depending on request path
         *
         * see: Mage_Core_Controller_Varien_Action::getFullActionName()
         */
        $fullActionName = $request->getRequestedRouteName().'_'.
            $request->getRequestedControllerName().'_'.
            $request->getRequestedActionName();

        // check caching blacklist for request routes
        $disableRoutes = explode("\n", trim(Mage::getStoreConfig(self::XML_PATH_VARNISH_CACHE_DISABLE_ROUTES)));
        foreach ($disableRoutes as $route) {
            $route = trim($route);
            // if route is found at first position we have a hit
            if (!empty($route) && strpos($fullActionName, $route) === 0) {
                return $this->setNoCacheHeader();
            }
        }

        // set TTL header
        $regexp = null;
        $value = null;
        $routesTtl = unserialize(Mage::getStoreConfig(self::XML_PATH_VARNISH_CACHE_ROUTES_TTL));
        if (is_array($routesTtl)) {
            foreach ($routesTtl as $routeTtl) {
                extract($routeTtl, EXTR_OVERWRITE);
                $regexp = trim($regexp);
                if (!empty($regexp) && strpos($fullActionName, $regexp) === 0) {
                    break;
                }
                $value = null;
            }
        }
        if (!isset($value)) {
            $value = Mage::getStoreConfig(self::XML_PATH_VARNISH_CACHE_TTL);
        }
        $this->setTtlHeader(intval($value));

        return $this;
    }
}
