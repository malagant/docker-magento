<?php

/**
 *  
 * @package Conlabz_VarnishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_VarnishReloader_Block_Javascript extends Mage_Core_Block_Template
{
    const DATA_KEY = 'data-varnish-placeholder';
    const XML_PATH_JAVASCRIPT_OPTIONS = 'global/varnishreloader/javascript_options';

    /**
     * retrieve script options for ajax reload
     * 
     * @return string
     */
    public function getOptionsJson()
    {
        $helper = $this->_getHelper();
        $currentStore = Mage::app()->getStore()->getCode();

        $options = [
            'cacheKey'        => 'vr_blocks_' . $currentStore,
            'dataKey'         => self::DATA_KEY,
            'isDebug'         => $helper->isDebug(),
            'ajaxUrl'         => $this->getUrl('varnishreloader/refresh/ajax', Mage::app()->getStore()->isCurrentlySecure() ? array('_secure' => 1) : array()),
            'currentStore'    => $currentStore,
            'loadingClass'    => 'varnishreloader-loading',
            'msgSelector'     => $helper->getMessageSelector(),
            'cookieRefresh'   => Conlabz_VarnishReloader_Helper_Data::COOKIE_FORCE_REFRESH,
            'uncacheable'     => $helper->isUncacheableAction(),
            'uenc'            => $this->helper('core/url')->getCurrentBase64Url()
        ];

        $options = array_merge($options, $this->_getAdditionalOptions());

        return Mage::helper('core')->jsonEncode($options);
    }

    /**
     * @return array
     */
    protected function _getAdditionalOptions()
    {
        $config = Mage::getConfig()->getNode(self::XML_PATH_JAVASCRIPT_OPTIONS);
        if ($config && $config->hasChildren()) {
            return $config->asArray();
        }
        return [];
    }

    /**
     * @return Conlabz_VarnishReloader_Helper_Data
     */
    protected function _getHelper()
    {
        return Mage::helper('varnishreloader');
    }
}
