<?php

$installer = $this;
/* @var $installer Mage_Core_Model_Resource_Setup */

$installer->startSetup();

/**
 * Update existing configuration to new paths
 */
$installer->run(
    'UPDATE '.$installer->getTable('core/config_data').'
    SET path = REPLACE(path, "system/varnishreloader/", "varnishcache/varnishreloader/")
    WHERE path LIKE "system/varnishreloader%"'
);

$installer->endSetup();
