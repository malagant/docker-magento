<?php

/**
 * @package Conlabz_VarnishReloader
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_VarnishReloader_RefreshController extends Mage_Core_Controller_Front_Action
{
    /**
     * reload dynamic data via ajax call
     */
    public function ajaxAction()
    {
        $responseData = array();

        // init all messages
        $storages = $this->_getHelper()->getSessionStorages();
        $this->_initLayoutMessages($storages);
        $responseData['messages'] = $this->getLayout()->getMessagesBlock()->toHtml();

        $this->loadLayout();

        // collect blocks
        foreach ($this->getLayout()->getAllBlocks() as $blockName => $block) {
            if ($block->getData('esi_options/method') === 'ajax') {
                $block->setIsEsiRequest(true);
                $responseData['blocks'][$blockName] = $block->toHtml();
            }
        }

        $responseDto = new Varien_Object($responseData);
        Mage::dispatchEvent('varnishreloader_response_send_before', array(
            'response_data' => $responseDto
        ));
        $responseData = $responseDto->getData();

        $this->_getHelper()->deleteRefreshCookie();
        Phoenix_VarnishCache_Helper_Cache::setNoCacheHeader();
        Mage::register(Phoenix_VarnishCache_Helper_Cache::REGISTRY_VAR_VARNISH_CACHE_CONTROL_HEADERS_SET_FLAG, 1, true);

        $this->getResponse()
            ->setHeader('Content-Type', 'application/json', true)
            ->setBody(Mage::helper('core')->jsonEncode($responseData));
    }

    /**
     * Surrogate-Capability
     */
    public function esiAction()
    {
        $blockName = $this->getRequest()->getParam('block', null);
        $result = '';
        if (null !== $blockName) {
            $this->loadLayout();
            $block = $this->getLayout()->getBlock($blockName);
            if ($block instanceof Mage_Core_Block_Template) {
                $block->setIsEsiRequest(true);
                $result = $block->toHtml();
            }
        }
        $this->getResponse()->setBody($result);
    }

    /**
     * Initializing layout messages by message storage(s), loading and adding messages to layout messages block
     *
     * overwritten: do not throw exception if storage has no messages
     *
     * @param string|array $messagesStorage
     * @return Mage_Core_Controller_Varien_Action
     */
    protected function _initLayoutMessages($messagesStorage)
    {
        if (!is_array($messagesStorage)) {
            $messagesStorage = array($messagesStorage);
        }
        foreach ($messagesStorage as $storageName) {
            $storage = Mage::getSingleton($storageName);
            if (false !== $storage && ($messages = $storage->getMessages(true))) {
                $block = $this->getLayout()->getMessagesBlock();
                $block->addMessages($messages);
                $block->setEscapeMessageFlag($storage->getEscapeMessages(true));
                $block->addStorageType($storageName);
            }
        }
        return $this;
    }

    /**
     * @return Conlabz_VarnishReloader_Helper_Data
     */
    protected function _getHelper()
    {
        return Mage::helper('varnishreloader');
    }
}
