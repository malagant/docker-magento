# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/) 
and this project adheres to [Semantic Versioning](http://semver.org/).


## [2.0.0] - 2017-02-03
### Changed
- Complete and clean rewrite of varnishreloader.js based on prototype.js (no jQuery anymore)
- Phoenix_VarnishCache is now a hard dependency
- Moved system.xml from `<system>` to `<varnishcache>` node
- All placeholders now must be defined within the `default` handle
- Use form_key cookie of Phoenix_VarnishCache module
- Renamed group name `con_varnishreloader` to `varnishreloader`
- Session storages for layout messages now must be explicitly registered under the `global/varnishreloader/session_storages` xml node
- renamed `set|getPlaceholderOptions` to `set|getEsiOptions`

### Added
- Added the ability to cache secure pages
- Added the ability to change js storage type via configuration
- ESI strategies
- CHANGELOG.md

### Removed
- Removed jQuery dependency

## [1.6.2] - 2015-12-14
### Added
- Added name for varnishreloader.js block

### Removed
- Removed JS-Plugin options: cookie domain and cookie path

## [1.6.1] - 2015-12-14
### Fixed
- Removed `head` block instead of `product.info` and `category`

## [1.6.0] - 2015-11-12
### Added
- Added composer.json

### Changed
- Moved templates and layout xml from /conlabz/varnishreloader/* to /varnishreloader/*

### Fixed
- Fixed no-cache cookie to not use http-only flag
- Disabled form key event observer of Phoenix_VarnishCache

### Removed
- Removed Cache warmer
