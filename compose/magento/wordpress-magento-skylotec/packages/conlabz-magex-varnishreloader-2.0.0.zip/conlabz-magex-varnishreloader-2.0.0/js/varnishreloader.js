/**
 * @class
 */
var ConVarnishReloader = Class.create();
ConVarnishReloader.prototype = {
    /**
     * @constructor
     * @param {Object} config
     * @param {Object} storage
     * @param {Object} cookies
     */
    initialize: function (config, storage, cookies)
    {
        var defaults = {
            isDebug:            true,
            cacheKey:           'refresh_blocks',
            dataKey:            'data-varnish-placeholder',
            ajaxUrl:            '/varnishreloader/refresh/ajax',
            cookieRefresh:      'refresh-ph',
            msgSelector:        '.col-main',
            uncacheable:        false,
            uenc:               '',
            loadingClass:       'varnishreloader-loading',
            env: {
                vrStore: config.currentStore,
                vrProtocol: window.location.protocol
            }
        };
        this.config  = Object.extend(defaults, config);
        this.storage = storage;
        this.cookies = cookies;
        this.refreshBlocks(false);
    },
    /**
     * @param {boolean} force
     * @returns {boolean}
     */
    refreshBlocks: function (force)
    {
        this._debug('Start refresh.');
        var cachedBlocks = this.getCachedBlocks();
        if (false !== cachedBlocks) {
            var result = this.updatePlaceholders(cachedBlocks);
            this._debug('Replaced cached blocks: ' + result.join(', '));
        }

        if (this.config.uncacheable && !force) {
            this._debug('Uncacheable page. Skipping refresh.');
            return false;
        }

        if (!this.requiresRefresh() && !force) {
            this._debug('No update required. Skipping refresh.');
            return false;
        }

        var self = this;
        new Ajax.Request(this.config.ajaxUrl, {
            method: 'get',
            onSuccess: function (response) {
                var json = response.responseJSON;
                if (json.hasOwnProperty('blocks')) {
                    result = self.updatePlaceholders(json.blocks);
                    self._debug('Refreshed blocks: ' + result.join(', '));
                }
                if (json.hasOwnProperty('messages')) {
                    self.insertMessages(json.messages);
                }
                self._debug('Finished refresh.');
            },
            onException: function (e) {
                console.log(e);
            }
        });

        return true;
    },
    /**
     * check if environment cookie has changed
     *
     * @returns {boolean}
     */
    hasEnvChanged: function ()
    {
        for (var type in this.config.env) {
            var cookieValue = this.cookies.get(type);
            if (!cookieValue) {
                this.cookies.set(type, this.config.env[type]);
            } else if (cookieValue != this.config.env[type]) {
                this.cookies.set(type, this.config.env[type]);
                this._debug('[Env:' + type + '] changed and forced refresh.');
                return true;
            }
        }
        return false;
    },
    /**
     * insert flash messages
     *
     * @param {string} messages
     */
    insertMessages: function (messages)
    {
        $$(this.config.msgSelector).each(function (elem) {
            elem.insert({ top: messages });
        });
    },
    /**
     * check if refresh of user data/blocks is required
     *
     * @returns {boolean}
     */
    requiresRefresh: function ()
    {
        if (this.cookies.get(this.config.cookieRefresh)) {
            this._debug('Refresh-cookie forces refresh.');
            return true;
        }
        return this.hasEnvChanged();
    },
    /**
     * retrieve placeholder collection
     *
     * @returns {*}
     */
    getPlaceholders: function ()
    {
        return $$('[' + this.config.dataKey + ']');
    },
    /**
     * @returns {number}
     */
    getCurrentPlaceholdersCount: function ()
    {
        return this.getPlaceholders().length;
    },
    /**
     * retrieve blocks from storage
     *
     * @returns {boolean}
     */
    getCachedBlocks: function ()
    {
        var cachedBlocks = this.storage.getItem(this.config.cacheKey);
        if (cachedBlocks) {
            return JSON.parse(cachedBlocks);
        }
        return false;
    },
    /**
     * update placeholders with new data/blocks
     *
     * @param {Object} blocks
     */
    updatePlaceholders: function (blocks)
    {
        this.storage.setItem(this.config.cacheKey, JSON.stringify(blocks));
        var dataKey = this.config.dataKey,
            result  = [];
        for (var blockName in blocks) {
            var html = this.filterHtml(blocks[blockName]);
            $$('[' + dataKey + '="' + blockName + '"]').each(function (element) {
                element.update(html);
                result.push(blockName);
            });
        }
        return result;
    },
    /**
     * filters html, currently only replaces encoded url with current real url
     *
     * @param {string} html
     * @returns {string}
     */
    filterHtml: function (html)
    {
        html = html.replace(/\/uenc\/[a-z0-9,]*\//gi, '/uenc/' + this.config.uenc + '/');
        return html;
    },
    /**
     * log debug info
     *
     * @param {string} message
     * @private
     */
    _debug: function (message)
    {
        if (this.config.isDebug) {
            console.log('[ConVarnishReloader] ' + message);
        }
    }
};
