<?php

/**
 * @package 
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_SkuRoute_Model_Observer
{
    public function addProductIdFromSku(Varien_Event_Observer $observer)
    {
        $event = $observer->getEvent();
        $action = $event->getControllerAction();
        $request = $action->getRequest();
        $productId = Mage::getModel('catalog/product')
            ->getIdBySku($request->getParam('sku'));
        if (!$productId) {
            return $this;
        }
        $request->setParam('id', $productId);
        return $this;
    }
}
