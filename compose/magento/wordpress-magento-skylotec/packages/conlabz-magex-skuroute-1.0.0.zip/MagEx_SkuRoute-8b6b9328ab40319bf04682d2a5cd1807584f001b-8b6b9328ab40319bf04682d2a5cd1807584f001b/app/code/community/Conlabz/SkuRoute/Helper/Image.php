<?php

/**
 * @package 
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_SkuRoute_Helper_Image extends Mage_Catalog_Helper_Image
{
    protected $_imageSize;

    /**
     * @return string
     */
    public function outputImage()
    {
        return file_get_contents($this->getNewFile());
    }
    
    public function create()
    {
        $this->__toString();
        return $this;
    }
    
    public function getMime()
    {
        $imgSize = $this->getImageSize();
        return $imgSize['mime'];
    }
    
    public function getNewFile()
    {
        return $this->_getModel()->getNewFile();
    }
    
    public function getImageSize()
    {
        if (null === $this->_imageSize) {
            $this->_imageSize = getImageSize($this->getNewFile());
        }
        return $this->_imageSize;
    }
}
