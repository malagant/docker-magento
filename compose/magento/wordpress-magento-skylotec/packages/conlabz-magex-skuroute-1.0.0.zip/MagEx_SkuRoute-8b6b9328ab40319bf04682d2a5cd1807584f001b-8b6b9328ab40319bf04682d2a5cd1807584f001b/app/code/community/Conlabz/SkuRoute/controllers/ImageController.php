<?php

/**
 * @package Conlabz_SkuRoute
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */
class Conlabz_SkuRoute_ImageController extends Mage_Core_Controller_Front_Action
{
    /**
     * @var int
     */
    protected $_width;

    /**
     * @var int
     */
    protected $_height;
    
    protected function _construct() 
    {
        parent::_construct();
        $this->_initSize();
    }
       
    public function productAction()
    {        
        $product = $this->_getProduct();
        $image = $this->_getHelper()
            ->init($product, 'image')
            ->resize($this->_width, $this->_height)
            ->create();
        $mime = $image->getMime();
        
        $this->getResponse()
            ->setHeader('Content-type', $mime, true)
            ->setBody($image->outputImage());
    }
    
    protected function _getProduct()
    {
        $sku = $this->getRequest()->getParam('sku');
        $productModel = Mage::getModel('catalog/product');
        $productId = $productModel->getIdBySku($sku);
        return $productModel->load($productId);
    }
    
    protected function _initSize()
    {
        $size = $this->getRequest()->getParam('size', 200);
        if (false !== strpos($size, 'x')) {
            list($width, $height) = explode('x', $size);
            $this->_width = (int) $width;
            $this->_height = (int) $height;
        } else {
            $this->_width = (int) $size;
            $this->_height = (int) $size;
        }
    }
    
    /**
     * 
     * @return Conlabz_SkuRoute_Helper_Image
     */
    protected function _getHelper()
    {
        return Mage::helper('skuroute/image');
    }
}
