# SKU route

After installation, products will be accessible with the following url:

http://example.com/<store>/sku/<sku-of-product>

