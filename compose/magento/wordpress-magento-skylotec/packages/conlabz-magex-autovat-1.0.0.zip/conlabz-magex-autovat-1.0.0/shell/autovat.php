<?php
/**
 * @package
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */

require 'abstract.php';

class Conlabz_Shell_AutoVat extends Mage_Shell_Abstract
{
    public function run()
    {
        /** @var Conlabz_AutoVat_Model_Cron $cron */
        $cron = Mage::getModel('autovat/cron');

        $fromDate = $this->getArg('from-date');
        $toDate   = $this->getArg('to-date');

        if ($fromDate) {
            $cron->setFromDate($fromDate);
        }
        if ($toDate) {
            $cron->setToDate($toDate);
        }

        $cron->run();
    }
}

$shell = new Conlabz_Shell_AutoVat();
$shell->run();
