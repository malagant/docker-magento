<?php
/**
 * @package
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */

class Conlabz_AutoVat_Helper_Data extends Mage_Core_Helper_Abstract
{
}
