<?php
/**
 * @package
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */

class Conlabz_AutoVat_Model_Resource_Tax_Calculation_Rate extends Mage_Tax_Model_Resource_Calculation_Rate
{
    public function update($taxCountryId, $oldRate, $newRate)
    {
        $write = $this->_getWriteAdapter();
        return $write->update(
            $this->getMainTable(),
            [
                'rate' => $newRate
            ],
            [
                'tax_country_id = ?' => $taxCountryId,
                'rate = ?' => $oldRate
            ]
        );
    }
}
