<?php
/**
 * @package
 * @author Cornelius Adams (conlabz GmbH) <cornelius.adams@conlabz.de>
 */

class Conlabz_AutoVat_Model_Cron
{
    /**
     * @var string
     */
    private $fromDate;

    /**
     * @var string
     */
    private $toDate;

    public function run()
    {
        $timeZone = new DateTimeZone('Europe/Berlin');
        $now      = new DateTime('now', $timeZone);
        $fromDate = new DateTime($this->getFromDate(), $timeZone);
        $toDate   = new DateTime($this->getToDate(), $timeZone);

        if ($now >= $fromDate && $now < $toDate) {
            $this->activate();
        } else {
            $this->deactivate();
        }
    }

    public function activate()
    {
        $this->_getResourceModel()->update('DE', 19, 16);
        $this->_getResourceModel()->update('DE', 7, 5);
    }

    public function deactivate()
    {
        $this->_getResourceModel()->update('DE', 16, 19);
        $this->_getResourceModel()->update('DE', 5, 7);
    }

    /**
     * @return string
     */
    public function getFromDate(): string
    {
        if ($this->fromDate) {
            return $this->fromDate;
        }
        return Mage::getStoreConfig('tax/calculation/autovat_from_date');
    }

    /**
     * @return string
     */
    public function getToDate(): string
    {
        if ($this->toDate) {
            return $this->toDate;
        }
        return Mage::getStoreConfig('tax/calculation/autovat_to_date');
    }

    /**
     * @param string $fromDate
     */
    public function setFromDate(string $fromDate): void
    {
        $this->fromDate = $fromDate;
    }

    /**
     * @param string $toDate
     */
    public function setToDate(string $toDate): void
    {
        $this->toDate = $toDate;
    }

    /**
     * @return Conlabz_AutoVat_Model_Resource_Tax_Calculation_Rate
     */
    protected function _getResourceModel()
    {
        return Mage::getResourceModel('autovat/tax_calculation_rate');
    }
}
